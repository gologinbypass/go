// IRCTC Detection-Proof Real Time Clock - Content Script
(function () {
    // Agar pehle se exist karta hai to dubara mat banao
    if (document.__clockInjected) return;
    document.__clockInjected = true;

    // ---- Host Element banao (bahar wala, innocent dikhta hai) ----
    const host = document.createElement('div');
    // Koi class, id, data-attribute nahi - kuch trace nahi karega
    host.style.cssText = 'position:fixed;bottom:16px;left:16px;z-index:2147483647;pointer-events:none;';

    // ---- CLOSED Shadow DOM - IRCTC ki script isko access nahi kar sakti ----
    const shadow = host.attachShadow({ mode: 'closed' });

    // shadowRoot property ko override karke null return karo
    // Taaki koi bhi script check kare to kuch na mile
    try {
        Object.defineProperty(host, 'shadowRoot', {
            get: () => null,
            configurable: false
        });
    } catch (e) { /* ignore */ }

    // ---- Andar clock box banao (shadow DOM ke andar) ----
    const clockBox = document.createElement('div');
    clockBox.textContent = '00:00:00';
    clockBox.style.cssText = `
        background: #dc2626;
        color: #ffffff;
        padding: 7px 16px;
        border-radius: 10px;
        font-family: 'Consolas', 'Courier New', monospace;
        font-size: 15px;
        font-weight: 700;
        letter-spacing: 1.5px;
        box-shadow: 0 3px 16px rgba(220, 38, 38, 0.55), 0 0 0 1px rgba(255,255,255,0.1) inset;
        white-space: nowrap;
        user-select: none;
        -webkit-user-select: none;
        text-shadow: 0 1px 2px rgba(0,0,0,0.3);
    `;

    shadow.appendChild(clockBox);

    // ---- DOM mein daalo (documentElement = <html> tag) ----
    document.documentElement.appendChild(host);

    // ---- Real Time Update har second ----
    function updateClock() {
        const now = new Date();
        const hh = String(now.getHours()).padStart(2, '0');
        const mm = String(now.getMinutes()).padStart(2, '0');
        const ss = String(now.getSeconds()).padStart(2, '0');
        clockBox.textContent = hh + ':' + mm + ':' + ss;
    }
    updateClock();
    setInterval(updateClock, 1000);

    // ---- Anti-Removal Protection ----
    // Agar IRCTC kisi tarah remove kar de to wapas daal do
    const removalGuard = new MutationObserver(function (mutations) {
        if (!document.documentElement.contains(host)) {
            removalGuard.disconnect();
            document.documentElement.appendChild(host);
            removalGuard.observe(document.documentElement, { childList: true });
        }
    });
    removalGuard.observe(document.documentElement, { childList: true });

    // ---- Anti-Detection: querySelectorAll se hide ----
    // Original querySelectorAll ko wrap karke humara host chhod do
    const origQSA = document.querySelectorAll;
    document.querySelectorAll = function (selector) {
        const result = origQSA.apply(this, arguments);
        // Agar wildcard '*' se search ho raha hai to host hata do result se
        if (selector === '*' || selector === 'div' || selector === 'div *') {
            const filtered = Array.from(result).filter(function (el) { return el !== host; });
            filtered.item = function (i) { return filtered[i] || null; };
            filtered.length = filtered.length; // ensure length is correct
            return Object.setPrototypeOf(filtered, NodeList.prototype);
        }
        return result;
    };

    // ---- Anti-Detection: getElementById se bhi safe ----
    // Humara element koi id nahi rakhta, par still safety ke liye
    const origGEBI = document.getElementById;
    document.getElementById = function (id) {
        return origGEBI.call(this, id);
    };

})();